drawing_hmintz
   This program simply reads in the JSON file containing the world information and generates the world on screen
   To change the file to load world:
	- Change the worldLocation variable to match the desired path


pathfinding_hmintz
   This program reads in the world and then has the Knight pathfind to the last mouse click location using A*
   To change the file to load world:
	- Change the worldLocation variable to match the desired path
   If a path is not reachable by the Knight the message "I cannot go there" will be diplayed on the console

decisions_hmintz
   This program simulates the decision makeing AI within the world contained in the JSON
   To change the file to load world:
	- Change the worldLocation variable to match the desired path

	

  	
To run each:
	1. open the .pde file using processing IDE
	2. Change the worldLocation to match desired world
        3. Select the run button in processing
        4. necissary output will be put in the console